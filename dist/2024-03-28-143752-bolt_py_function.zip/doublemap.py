import requests

organization = "ucf"
URL = "http://" + organization + ".doublemap.com/map/v2/"

def get_buses():
    response = requests.get(URL + "buses")
    return response.json()

def get_eta(stop_id, route_id):
    response = requests.get(URL + "eta?stop=" + str(stop_id))
    etas = response.json().get(str(stop_id)).get("etas")
    min = 1000
    for eta in etas:
        if eta.get("route") == route_id and eta.get("avg") < min:
            min = eta.get("avg")
    return min